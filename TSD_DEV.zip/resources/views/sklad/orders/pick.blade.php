@extends('layouts.app')
@section('content')
    @include('sklad.header_adm')

    <style>
        body {
            background: #f5f6f7;
        }

        header,
        footer,
        #search_container {
            display: none !important;
        }

        .sklad-page {
            min-height: calc(100vh - 70px);
            padding: 18px 12px 30px;
            background:
                linear-gradient(135deg, rgba(255, 198, 0, 0.07), rgba(255,255,255,0.96)),
                #f5f6f7;
        }

        .sklad-shell {
            max-width: 430px;
            margin: 0 auto;
        }

        .sklad-top-card {
            background: #ffffff;
            border-radius: 16px;
            box-shadow: 0 12px 32px rgba(0, 0, 0, 0.10);
            overflow: hidden;
            border-top: 5px solid #f3c400;
        }

        .sklad-header {
            padding: 18px 18px 16px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-bottom: 1px solid #eceff3;
            gap: 12px;
        }

        .sklad-header-title {
            margin: 0;
            font-size: 22px;
            font-weight: 800;
            color: #171717;
            line-height: 1.2;
        }

        .sklad-header-subtitle {
            margin-top: 4px;
            font-size: 13px;
            color: #777777;
        }

        .sklad-header-icon {
            width: 44px;
            height: 44px;
            border-radius: 12px;
            background: #171717;
            color: #f3c400 !important;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
            text-decoration: none !important;
            font-size: 24px;
            font-weight: 900;
        }

        .sklad-body {
            padding: 18px;
        }

        #activeCellBanner {
            max-width: 430px;
            margin: 0 auto 14px !important;
            border: 1px solid rgba(243, 196, 0, 0.35) !important;
            border-radius: 14px !important;
            background: rgba(243, 196, 0, 0.13) !important;
            color: #171717 !important;
            font-weight: 800;
            font-size: 13px;
            padding: 12px 14px !important;
        }

        .btn-arrow {
            width: 44px;
            height: 44px;
            font-size: 22px;
            border-radius: 12px;
            border: none;
            background: #171717 !important;
            color: #f3c400 !important;
            font-weight: 900;
        }

        #docTabs {
            border-bottom: none;
            display: flex;
            gap: 8px;
            margin-bottom: 16px !important;
        }

        #docTabs .nav-item {
            flex: 1;
        }

        .custom-tab {
            width: 100%;
            text-align: center;
            background: #eef0f3 !important;
            color: #171717 !important;
            border: none !important;
            border-radius: 11px !important;
            font-weight: 800;
            font-size: 14px;
            padding: 11px 8px !important;
        }

        .custom-tab.active {
            background: #f3c400 !important;
            color: #171717 !important;
        }

        /* =========================
           ДОКУМЕНТЫ
           один блок = один radius
           без Bootstrap .card и без .doc-header
           ========================= */

        #documentsList {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        #documentsList.list-group-flush .list-group-item + .list-group-item {
            border-top-width: 1px !important;
        }

        #documentsList .doc-line {
            display: flex;
            flex-direction: column;
            gap: 8px;
            background: #ffffff !important;
            border: 1px solid #e7e9ee !important;
            border-radius: 16px !important;
            padding: 16px 44px 16px 16px !important;
            margin: 0 !important;
            box-shadow: 0 8px 22px rgba(0, 0, 0, 0.07);
            cursor: pointer;
            position: relative;
            color: #171717;
            transition: 0.18s ease;
            overflow: hidden;
        }

        #documentsList .doc-line:hover {
            transform: translateY(-1px);
            box-shadow: 0 12px 26px rgba(0, 0, 0, 0.10);
            border-color: rgba(243, 196, 0, 0.75) !important;
        }

        #documentsList .doc-line::after {
            content: "›";
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #dc3545;
            font-size: 30px;
            font-weight: 900;
        }

        .doc-title {
            font-weight: 800;
            line-height: 1.35;
            word-break: break-word;
            color: #171717;
            font-size: 14px;
        }

        .doc-badge {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 38px;
            height: 24px;
            border-radius: 999px;
            background: rgba(243, 196, 0, 0.15);
            color: #171717;
            font-weight: 900;
            font-size: 11px;
            margin-right: 8px;
            margin-bottom: 8px;
        }

        .doc-meta {
            color: #777777;
            font-size: 12px;
            font-weight: 700;
            line-height: 1.35;
        }

        #barcodeInput {
            height: 52px;
            border-radius: 11px;
            border: 1px solid #d9dde2;
            box-shadow: none;
            font-size: 16px;
            font-weight: 700;
        }

        #barcodeInput:focus {
            border-color: #f3c400;
            box-shadow: 0 0 0 0.2rem rgba(243, 196, 0, 0.18);
        }

        #positionsUl .list-group-item {
            display: flex;
            flex-direction: column;
            gap: 8px;
            background: #ffffff !important;
            border: 1px solid #e7e9ee !important;
            border-radius: 16px !important;
            padding: 16px !important;
            margin-bottom: 12px;
            box-shadow: 0 8px 22px rgba(0, 0, 0, 0.07);
        }

        .pos-title {
            font-weight: 800;
            line-height: 1.25;
            word-break: break-word;
            color: #171717;
            font-size: 14px;
        }

        .pos-qty {
            margin-top: 2px;
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }

        .qty-chip {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 5px 10px;
            border: none;
            border-radius: 999px;
            background: rgba(243, 196, 0, 0.15);
            color: #171717;
            font-weight: 900;
            font-size: 12px;
            line-height: 1;
            white-space: nowrap;
        }

        .qty-chip.fact {
            background: #171717;
            color: #f3c400;
        }

        .hl-barcode,
        #positionsUl.list-group-flush .list-group-item.hl-barcode {
            background: rgba(243, 196, 0, 0.12) !important;
            border-color: #f3c400 !important;
            font-weight: 800;
        }

        #btnSend {
            width: 100%;
            height: 48px;
            border: none !important;
            border-radius: 11px !important;
            background: #dc3545 !important;
            color: #ffffff !important;
            font-size: 15px;
            font-weight: 800;
        }

        .btn-dark {
            width: 100%;
            height: 44px;
            border: none !important;
            border-radius: 11px !important;
            background: #eef0f3 !important;
            color: #171717 !important;
            font-weight: 800;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .scan-confirm-overlay {
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,.45);
            z-index: 9999;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 15px;
        }

        .scan-confirm-box {
            background: #fff;
            border-radius: 16px;
            border-top: 5px solid #f3c400;
            padding: 18px;
            max-width: 430px;
            width: 100%;
            box-shadow: 0 12px 32px rgba(0,0,0,.25);
        }

        .scan-confirm-title {
            font-weight: 800;
            font-size: 18px;
            margin-bottom: 10px;
            color: #171717;
        }

        .scan-confirm-text {
            font-size: 14px;
            white-space: pre-line;
            max-height: 300px;
            overflow-y: auto;
            margin-bottom: 15px;
        }

        .scan-confirm-actions {
            display: flex;
            gap: 10px;
            justify-content: flex-end;
        }

        #positionsUl .list-group-item.border-danger {
            border: 2px solid #dc3545 !important;
            background: #ffe6e9 !important;
        }

        .send-status-overlay {
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,.55);
            z-index: 10000;
            display: none;
            align-items: center;
            justify-content: center;
            padding: 15px;
        }

        .send-status-overlay.show {
            display: flex;
        }

        .send-status-box {
            background: #fff;
            border-radius: 16px;
            border-top: 5px solid #f3c400;
            padding: 24px 20px;
            max-width: 380px;
            width: 100%;
            text-align: center;
            box-shadow: 0 12px 32px rgba(0,0,0,.25);
        }

        .send-status-icon {
            width: 62px;
            height: 62px;
            border-radius: 16px;
            background: #171717;
            color: #f3c400;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 14px;
            font-size: 34px;
            font-weight: 900;
        }

        .send-status-icon.success {
            background: #198754;
            color: #ffffff;
        }

        .send-status-title {
            font-size: 20px;
            font-weight: 900;
            color: #171717;
            margin-bottom: 6px;
        }

        .send-status-text {
            font-size: 14px;
            color: #777777;
            font-weight: 700;
        }

        .send-status-spinner {
            width: 34px;
            height: 34px;
            border: 4px solid rgba(243, 196, 0, 0.25);
            border-top-color: #f3c400;
            border-radius: 50%;
            animation: sendSpin .8s linear infinite;
        }

        @keyframes sendSpin {
            to {
                transform: rotate(360deg);
            }
        }

        @media (max-width: 480px) {
            .sklad-page {
                padding: 12px 10px 24px;
            }

            .sklad-body {
                padding: 14px;
            }

            .sklad-header-title {
                font-size: 20px;
            }

            #documentsList .doc-line,
            .doc-title {
                font-size: 13px;
            }
        }
    </style>

    <div class="content sklad-page" style="min-height:100%">
        <section class="content">
            <div class="sklad-shell">
                <div class="sklad-top-card">

                    <div class="sklad-header">
                        <div>
                            <h1 class="sklad-header-title" id="pageTitle">Документы отбора</h1>
                            <div class="sklad-header-subtitle">Размещение · складские операции</div>
                        </div>

                        <a href="{{ route('sklad.index') }}"
                           class="sklad-header-icon"
                           title="Главная">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-house-down" viewBox="0 0 16 16">
                                <path d="M7.293 1.5a1 1 0 0 1 1.414 0L11 3.793V2.5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v3.293l2.354 2.353a.5.5 0 0 1-.708.708L8 2.207l-5 5V13.5a.5.5 0 0 0 .5.5h4a.5.5 0 0 1 0 1h-4A1.5 1.5 0 0 1 2 13.5V8.207l-.646.647a.5.5 0 1 1-.708-.708z"/>
                                <path d="M12.5 9a3.5 3.5 0 1 1 0 7 3.5 3.5 0 0 1 0-7m.354 5.854 1.5-1.5a.5.5 0 0 0-.708-.707l-.646.646V10.5a.5.5 0 0 0-1 0v2.793l-.646-.646a.5.5 0 0 0-.708.707l1.5 1.5a.5.5 0 0 0 .708 0"/>
                            </svg>
                        </a>
                    </div>

                    <div class="sklad-body">

                        <button id="btnBack"
                                type="button"
                                class="btn-arrow d-none mb-3"
                                aria-label="Назад">←</button>

                        <ul class="nav nav-tabs mb-3" id="docTabs">
                            <li class="nav-item">
                                <a class="nav-link custom-tab active" href="#" data-tab="gp">ГП</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link custom-tab" href="#" data-tab="dopy">ДО</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link custom-tab" href="#" data-tab="kom">КО</a>
                            </li>
                        </ul>

                        <div id="barcodeWrapper" class="mb-3 d-none">
                            <input id="barcodeInput"
                                   type="text"
                                   class="form-control form-control-lg"
                                   placeholder="Сканируйте номенклатуру или штрихкод..."
                                   autocomplete="off">
                        </div>

                        <div id="documentsList" class="list-group list-group-flush">
                            @foreach(session('pick_orders', []) as $i => $doc)
                                <div class="list-group-item doc-line select-doc" data-doc-index="{{ $i }}">
                                    <div class="doc-title">
                                        <span class="doc-badge">DOC</span>
                                        {{ $doc['Ссылка'] ?? 'Без названия' }} — Статус: {{ $doc['Статус'] ?? '-' }}
                                    </div>

                                    <div class="doc-meta">
                                        Склад: {{ $doc['Склад'] ?? '-' }}<br>
                                        Помещение: {{ $doc['Помещение'] ?? '-' }}
                                    </div>
                                </div>
                            @endforeach
                        </div>

                        <div id="positionsList" class="d-none">
                            <ul class="list-group list-group-flush" id="positionsUl">
                                {{-- строки вставляются через JS --}}
                            </ul>
                        </div>

                        <div class="mt-3">
                            <button id="btnSend"
                                    type="button"
                                    class="btn btn-primary btn-lg w-100 d-none"
                                    data-send-url="{{ route('sklad.acceptance.finish') }}">
                                Отправить
                            </button>
                        </div>

                        <div class="mt-3">
                            <a href="{{ route('sklad.index') }}" class="btn btn-dark">Главная</a>
                        </div>

                    </div>
                </div>
            </div>
        </section>
    </div>

    <div id="sendStatusOverlay" class="send-status-overlay">
        <div class="send-status-box">
            <div id="sendStatusIcon" class="send-status-icon">
                <div class="send-status-spinner"></div>
            </div>

            <div id="sendStatusTitle" class="send-status-title">
                Данные отправляются...
            </div>

            <div id="sendStatusText" class="send-status-text">
                Подождите, идёт передача данных в 1С
            </div>
        </div>
    </div>
@endsection

@push('scripts')
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            console.log('[pick] DOM ready');

            const documents = @json(session('pick_orders', [])) || [];

            const FREE_SCAN_PAGE = @json(route('sklad.scan.free'));
            const hasDocuments = Array.isArray(documents) && documents.length > 0;
            if (!hasDocuments) {
                window.location.replace(FREE_SCAN_PAGE);
                return;
            }

            // ===== DOM =====
            const docList = document.getElementById('documentsList');
            const posList = document.getElementById('positionsList');
            const posUl   = document.getElementById('positionsUl');
            const backBtn = document.getElementById('btnBack');
            const title   = document.getElementById('pageTitle');
            const input   = document.getElementById('barcodeInput');
            const barcodeWrapper = document.getElementById('barcodeWrapper');
            const btnSend = document.getElementById('btnSend');

            const sendStatusOverlay = document.getElementById('sendStatusOverlay');
            const sendStatusIcon    = document.getElementById('sendStatusIcon');
            const sendStatusTitle   = document.getElementById('sendStatusTitle');
            const sendStatusText    = document.getElementById('sendStatusText');

            function showSendingModal() {
                if (!sendStatusOverlay) return;

                sendStatusIcon.className = 'send-status-icon';
                sendStatusIcon.innerHTML = '<div class="send-status-spinner"></div>';

                sendStatusTitle.textContent = 'Данные отправляются...';
                sendStatusText.textContent = 'Подождите, идёт передача данных в 1С';

                sendStatusOverlay.classList.add('show');
            }

            function showSentModal(message = 'Данные успешно отправлены') {
                if (!sendStatusOverlay) return;

                sendStatusIcon.className = 'send-status-icon success';
                sendStatusIcon.innerHTML = '✓';

                sendStatusTitle.textContent = 'Отправлено';
                sendStatusText.textContent = message;
            }

            // скрываем кнопку отправки по умолчанию
            if (btnSend) btnSend.classList.add('d-none');

            // ===== Константы/роуты =====

            const CODE_MAX        = 11; // длина scan_position_document.code
            const POS_SAVE_URL    = @json(route('sklad.scan.position.store'));
            const STATE_FETCH_URL = @json(route('sklad.scan.session.state'));
            const SEND_URL        = @json(route('sklad.scan.send'));
            const SEARCH_BARCODE_URL = @json(route('sklad.scan.search.barcode'));
            const ADD_EXTERNAL_POS_URL = @json(route('sklad.scan.addLineByNumber'));

            const csrf = document.querySelector('meta[name="csrf-token"]')?.content || '';
            const FINISH_URL = @json(route('sklad.tsd.finish_acceptance'));

            const CELL_LABEL_URL = @json(route('sklad.cell.label'));
            console.log('[pick] routes:', { POS_SAVE_URL, STATE_FETCH_URL, SEND_URL, SEARCH_BARCODE_URL });

            // ===== Активная ячейка (state из сессии/кеша) =====
            let activeCellTextNorm = '';

            let activeState = null;
            let currentCellNameFor1C = null; // имя ячейки, которое шлём в 1С как cell_name

            // Баннер активной ячейки
            let banner = document.getElementById('activeCellBanner');
            if (!banner) {
                banner = document.createElement('div');
                banner.id = 'activeCellBanner';
                banner.className = 'alert alert-info d-none';
                const container = document.querySelector('#tabsContainer') || document.body;
                container.prepend(banner);
            }

            // Tabs
            const tabs = document.querySelectorAll('.custom-tab');
            let activeTab = 'gp';
            tabs.forEach(t => t.dataset.baseLabel = t.textContent.trim());

            const norm = s => (String(s || '')).trim().toLowerCase();

            // ======== Маппинг вкладок -> Помещения ========
            const ROOM_BY_TAB = {
                gp:   ['гп (ячейки)', 'гп', 'готовая продукция'],
                dopy: ['до', 'доп', 'допы', 'доп. материалы'],
                kom:  ['ко', 'комплект', 'комплектующие']
            };

            // ======== Словари для определения склада по ячейке ========
            const CELL_KEYWORDS = {
                gp:   ['гп', 'готов', 'хранение гп', 'яч гп'],
                dopy: ['доп', 'до'],
                kom:  ['ком', 'комплект']
            };

            const WAREHOUSE_BY_TAB = { gp: 1, dopy: 2, kom: 3 }; // реальные id складов

            function detectTabByCellText(cellText) {
                const c = (cellText || '').toString().trim().toLowerCase();
                if (!c) return null;
                if (CELL_KEYWORDS.gp.some(k => c.includes(k)))   return 'gp';
                if (CELL_KEYWORDS.dopy.some(k => c.includes(k))) return 'dopy';
                if (CELL_KEYWORDS.kom.some(k => c.includes(k)))  return 'kom';
                return null;
            }

            function inferWarehouseFromFirstRowCell() {
                const firstLi = document.querySelector('#positionsUl li');
                if (!firstLi) return null;
                const cellTxt = firstLi.dataset.cell || '';
                const tab = detectTabByCellText(cellTxt);
                return tab ? (WAREHOUSE_BY_TAB[tab] ?? null) : null;
            }

            function setWarehouseInStateIfMissing() {
                if (activeState && !activeState.warehouse_id) {
                    activeState.warehouse_id = currentWarehouseId;
                    console.log('[STATE] warehouse_id set →', currentWarehouseId);
                }
            }

            function matchesTabByRoom(room, tab = activeTab) {
                const r = norm(room);
                const patterns = ROOM_BY_TAB[tab] || [];
                if (!patterns.length) return true;
                return patterns.some(p => r.includes(p));
            }

            function matchesTabByCell(cell, tab = activeTab) {
                const c = norm(cell);
                if (tab === 'gp')   return c.includes('гп') || c.includes('готов') || c === '';
                if (tab === 'dopy') return c.includes('доп') || c === '';
                if (tab === 'kom')  return c.includes('ком') || c === '';
                return true;
            }

            function updateTabBadges(counts) {
                const fallback = { gp: 'ГП', dopy: 'ДО', kom: 'КО' };
                tabs.forEach(t => {
                    const code = t.dataset.tab || 'gp';
                    const base = t.dataset.baseLabel || fallback[code] || t.textContent.trim();
                    t.textContent = `${base} ${counts[code] ?? 0}`;
                });
            }

            async function loadCellState() {
                try {
                    // 1) Забираем state
                    const r = await fetch(STATE_FETCH_URL, { headers: { 'Accept': 'application/json' } });
                    const j = await r.json().catch(() => ({}));
                    activeState = j.state || null;

                    // 2) Сбрасываем и подготавливаем баннер
                    banner.classList.remove('d-none', 'alert-warning', 'alert-info');

                    const raw = activeState?.cell ?? '';
                    if (!raw) {
                        activeCellTextNorm = '';
                        banner.classList.add('alert-warning');
                        banner.textContent = 'Ячейка не выбрана. Сначала отсканируйте ячейку на экране "Размещение".';
                        return;
                    }

                    // 3) Пытаемся получить красивую метку/помещение/вкладку с бэка
                    let nice = null, room = null, tab = null;
                    try {
                        const r2  = await fetch(CELL_LABEL_URL + '?number=' + encodeURIComponent(raw));
                        const j2  = await r2.json();
                        nice = (j2?.label ?? null);
                        room = (j2?.room  ?? null);
                        tab  = (j2?.tab   ?? null);
                    } catch (_) {
                        // игнор — используем локальные эвристики
                    }

                    // 4) Баннер
                    banner.classList.add('alert-info');
                    const label = nice || raw;
                    banner.textContent = room ? `Ячейка: ${label} (Помещение: ${room})` : `Ячейка: ${label}`;

                    // 5) Нормализованный текст активной ячейки — нужен для проверки инкремента «Факт»
                    activeCellTextNorm = norm(label || raw || '');

                    // 5.1) Сохраняем «имя ячейки для 1С» (его и будем отправлять как cell_name)
                    currentCellNameFor1C = label || raw || null;

                    // 6) Если бэк не вернул вкладку — пробуем определить по тексту ячейки
                    if (!tab) {
                        tab = detectTabByCellText(label) || detectTabByCellText(raw) || null;
                    }

                    // 7) Пробуем проставить warehouse_id, если его ещё нет
                    if (activeState && !activeState.warehouse_id) {
                        let wh = null;
                        if (tab && WAREHOUSE_BY_TAB && WAREHOUSE_BY_TAB[tab]) {
                            wh = WAREHOUSE_BY_TAB[tab];
                        }
                        if (!wh) {
                            wh = inferWarehouseFromFirstRowCell();
                        }
                        if (wh) {
                            activeState.warehouse_id = wh;
                            if (typeof currentWarehouseId !== 'undefined' && (currentWarehouseId == null)) {
                                currentWarehouseId = wh;
                            }
                            console.log('[STATE] warehouse_id set →', wh);
                        }
                    }

                    // 8) Если определили вкладку — показываем только её и перерисовываем контент
                    if (tab) {
                        activeTab = tab;

                        tabs.forEach(t => {
                            const isActive = (t.dataset.tab === activeTab);
                            t.classList.toggle('active', isActive);
                            t.classList.toggle('d-none', !isActive);
                        });

                        const onDocsScreen = !docList.classList.contains('d-none');
                        if (onDocsScreen) {
                            renderDocuments();
                        } else if (typeof applyTabFilterInPositions === 'function') {
                            applyTabFilterInPositions();
                        }
                    }
                } catch (e) {
                    console.warn('Не удалось получить state ячейки', e);
                }
            }

            // ============== список документов ==============
            function renderDocuments() {
                docList.innerHTML = '';

                const docCounts = { gp:0, dopy:0, kom:0 };
                documents.forEach(d => {
                    if (matchesTabByRoom(d.Помещение, 'gp'))   docCounts.gp++;
                    if (matchesTabByRoom(d.Помещение, 'dopy')) docCounts.dopy++;
                    if (matchesTabByRoom(d.Помещение, 'kom'))  docCounts.kom++;
                });
                updateTabBadges(docCounts);

                const filtered = documents.filter(d => matchesTabByRoom(d.Помещение, activeTab));

                // ⬇️ если в текущей вкладке пусто — уходим в free
                if (filtered.length === 0) {
                    window.location.replace(FREE_SCAN_PAGE);
                    return;
                }

                filtered.forEach((doc) => {
                    const realIndex = documents.indexOf(doc);

                    const item = document.createElement('div');
                    item.className = 'list-group-item doc-line select-doc';
                    item.dataset.docIndex = realIndex;

                    item.innerHTML = `
                        <div class="doc-title">
                            <span class="doc-badge">DOC</span>
                            ${doc.Ссылка ?? 'Без названия'} — Статус: ${doc.Статус ?? '-'}
                        </div>

                        <div class="doc-meta">
                            Склад: ${doc.Склад ?? '-'}<br>
                            Помещение: ${doc.Помещение ?? '-'}
                        </div>
                    `;

                    docList.appendChild(item);
                });

                docList.querySelectorAll('.select-doc').forEach(el => {
                    el.addEventListener('click', () => showPositions(el.dataset.docIndex));
                });
            }

            function showDocuments() {
                docList.classList.remove('d-none');
                posList.classList.add('d-none');
                backBtn.classList.add('d-none');
                barcodeWrapper.classList.add('d-none');
                title.textContent = 'Документы отбора';
                posUl.innerHTML = '';
                input.value = '';

                // прячем кнопку "Отправить" на экране списка документов
                if (btnSend) btnSend.classList.add('d-none');

                // Оставляем только уже выбранную вкладку
                tabs.forEach(t => {
                    const isActive = (t.dataset.tab === activeTab);
                    t.classList.toggle('active', isActive);
                    t.classList.toggle('d-none', !isActive);
                    t.textContent = t.dataset.baseLabel || t.textContent.trim();
                });

                loadCellState();
            }

            // ============== экран позиций документа ==============
            function recomputeCountsByCells() {
                const counts = { gp:0, dopy:0, kom:0 };
                document.querySelectorAll('#positionsUl li').forEach(li => {
                    const cell = li.dataset.cell || '';
                    if (matchesTabByCell(cell, 'gp'))   counts.gp++;
                    if (matchesTabByCell(cell, 'dopy')) counts.dopy++;
                    if (matchesTabByCell(cell, 'kom'))  counts.kom++;
                });
                updateTabBadges(counts);
            }

            function applyTabFilterInPositions() {
                document.querySelectorAll('#positionsUl li').forEach(li => {
                    const cell = li.dataset.cell || '';
                    li.classList.toggle('d-none', !matchesTabByCell(cell));
                });
                document.querySelectorAll('#positionsUl li.d-none')
                    .forEach(li => li.classList.remove('hl-barcode'));
            }

            function detectTabByRoom(room) {
                const r = norm(room);
                if (ROOM_BY_TAB.gp.some(p => r.includes(p)))   return 'gp';
                if (ROOM_BY_TAB.dopy.some(p => r.includes(p))) return 'dopy';
                if (ROOM_BY_TAB.kom.some(p => r.includes(p)))  return 'kom';
                return 'gp';
            }

            function getDocumentNoFromDoc(doc) {
                if (typeof doc.document_id === 'string' && doc.document_id.trim()) {
                    return doc.document_id.trim();
                }
                const m = String(doc.Ссылка || '').match(/\b(00-\d+)\b/);
                return m ? m[1] : '';
            }

            let currentDocIndex = null;
            let currentDocNo = '';
            let currentDoc = null;
            let currentWarehouseId = null;

            function renderLi(li) {
                const rownum = li.dataset.line || '';
                const nom    = li.dataset.nomOriginal || '-';
                const qtyPln = Number(li.dataset.qty || 0);
                const qtyFct = Number(li.dataset.fact || 0);

                li.innerHTML = `
                    <div class="pos-title">#${rownum} — ${nom}</div>
                    <div class="pos-qty">
                        <span class="qty-chip plan">План: ${qtyPln}</span>
                        <span class="qty-chip fact">Факт: ${qtyFct}</span>
                    </div>`;
            }

            function getNextLineNumber() {
                let max = 0;
                document.querySelectorAll('#positionsUl li').forEach(li => {
                    const n = parseInt(li.dataset.line || '', 10);
                    if (!Number.isNaN(n) && n > max) max = n;
                });
                return max + 1;
            }

            function aggKeyFor(found, code) {
                const bc = String(found?.barcode || code || '').trim().toLowerCase();
                if (bc) return 'bc:' + bc;
                const nom = String(found?.nomen || '').trim().toLowerCase();
                return 'nom:' + nom;
            }

            function getOrCreateAggLi(key, displayNom, displayBarcode) {
                let li = document.querySelector(`#positionsUl li[data-agg-key="${key}"]`);
                if (li) return li;

                li = document.createElement('li');
                li.className = 'list-group-item agg-line';
                li.dataset.aggKey      = key;
                li.dataset.nom         = (displayNom || '').toLowerCase();
                li.dataset.nomOriginal = displayNom || '-';
                li.dataset.barcode     = (displayBarcode || '').toLowerCase();
                li.dataset.cell        = norm(currentCellNameFor1C || activeState?.cell || '');
                li.dataset.line        = String(getNextLineNumber());
                li.dataset.qty         = li.dataset.qty || '0';
                li.dataset.fact        = '0';

                const badge = document.createElement('span');
                badge.className = 'badge badge-warning ml-2';
                badge.dataset.badge = 'pending';
                badge.textContent = 'Отправляем...';

                li.innerHTML = `
                    <div class="pos-title">#${li.dataset.line} — ${li.dataset.nomOriginal}</div>
                    <div class="pos-qty">
                        <span class="qty-chip plan">План: ${Number(li.dataset.qty) || 0}</span>
                        <span class="qty-chip fact">Факт: 0</span>
                    </div>
                `;
                li.querySelector('.pos-title')?.appendChild(badge);

                posUl.appendChild(li);

                if (typeof recomputeCountsByCells === 'function') recomputeCountsByCells();
                if (typeof applyTabFilterInPositions === 'function') applyTabFilterInPositions();

                return li;
            }

            function updateLiCounts(li) {
                const qtyPln = Number(li.dataset.qty || 0) || 0;
                const qtyFct = Number(li.dataset.fact || 0) || 0;
                li.querySelector('.pos-qty .plan')?.replaceChildren(document.createTextNode(`План: ${qtyPln}`));
                li.querySelector('.pos-qty .fact')?.replaceChildren(document.createTextNode(`Факт: ${qtyFct}`));
            }

            function setPending(li, delta) {
                const cur = Number(li.dataset.pending || 0);
                const next = Math.max(0, cur + delta);
                li.dataset.pending = String(next);
                let badge = li.querySelector('[data-badge="pending"]');

                if (next > 0) {
                    if (!badge) {
                        badge = document.createElement('span');
                        badge.className = 'badge badge-warning ml-2';
                        badge.dataset.badge = 'pending';
                        li.querySelector('.pos-title')?.appendChild(badge);
                    }
                    badge.textContent = `Отправляем... (${next})`;
                    badge.className = 'badge badge-warning ml-2';
                } else {
                    if (badge) {
                        badge.textContent = 'В документе';
                        badge.className = 'badge badge-success ml-2';
                    }
                }
            }

            async function appendExternalItem(found, code) {
                const displayNom     = found?.nomen || '(по штрихкоду)';
                const displayBarcode = found?.barcode || code || '';

                const key = aggKeyFor(found, code);
                const li  = getOrCreateAggLi(key, displayNom, displayBarcode);

                li.dataset.fact = String((Number(li.dataset.fact || 0) || 0) + 1);
                li.classList.add('hl-barcode');
                updateLiCounts(li);
                li.scrollIntoView({ block: 'nearest', behavior: 'smooth' });

                setPending(li, +1);

                try {
                    const payload = {
                        document_no: String(currentDocNo),
                        code: String(displayBarcode),
                        quantity: 1,

                        document_id: String(currentDocNo),
                        warehouse_id: currentWarehouseId,
                        active_cell: activeState?.cell || null,
                        barcode: String(displayBarcode),
                        nomen: found?.nomen || null,
                        characteristic: found?.characteristic || null,
                        fill_placed: true,
                        line_no_hint: Number(li.dataset.line) || undefined,
                        doc_link: currentDoc?.Ссылка || null,

                        cell_name: currentCellNameFor1C || null,

                        scan_id: (window.crypto?.randomUUID?.() || Date.now()+''),
                    };

                    const resp = await fetch(ADD_EXTERNAL_POS_URL, {
                        method: 'POST',
                        headers: {
                            'X-CSRF-TOKEN': csrf,
                            'X-Requested-With': 'XMLHttpRequest',
                            'Accept': 'application/json',
                            'Content-Type': 'application/json',
                        },
                        credentials: 'same-origin',
                        body: JSON.stringify(payload),
                    });

                    const raw = await resp.text();
                    let data = {};
                    try { data = raw ? JSON.parse(raw) : {}; } catch(e) {}

                    if (!resp.ok || !data.ok) {
                        li.dataset.fact = String(Math.max(0, (Number(li.dataset.fact || 0) || 0) - 1));
                        updateLiCounts(li);
                        setPending(li, -1);
                        alert((data && (data.msg || JSON.stringify(data))) || ('HTTP ' + resp.status));
                        return;
                    }

                    setPending(li, -1);

                } catch (e) {
                    console.error('[ADD-EXTERNAL] fetch error', e);
                    li.dataset.fact = String(Math.max(0, (Number(li.dataset.fact || 0) || 0) - 1));
                    updateLiCounts(li);
                    setPending(li, -1);
                    alert('Ошибка при добавлении позиции в документ.');
                }
            }

            function aggKeyFromRow(line) {
                const bc  = String(line.Штрихкод || '').trim().toLowerCase();
                if (bc) return 'bc:' + bc;
                const nom = String(line.Номенклатура || '').trim().toLowerCase();
                return 'nom:' + nom;
            }

            function showPositions(index) {
                const doc = documents[index];
                if (!doc) return;

                currentDocIndex = index;
                currentDocNo = getDocumentNoFromDoc(doc);
                currentDoc = doc;

                currentWarehouseId = (doc.warehouse_id ?? activeState?.warehouse_id) ?? null;

                window.currentDocumentId = currentDocNo;
                console.log('[DOC] opened', { link: doc?.Ссылка, currentDocNo, currentWarehouseId });

                const docTab = detectTabByRoom(doc.Помещение);
                activeTab = docTab;
                tabs.forEach(t => {
                    if (t.dataset.tab === docTab) {
                        t.classList.add('active');
                        t.classList.remove('d-none');
                    } else {
                        t.classList.add('d-none');
                        t.classList.remove('active');
                    }
                });

                docList.classList.add('d-none');
                posList.classList.remove('d-none');
                backBtn.classList.remove('d-none');
                barcodeWrapper.classList.remove('d-none');
                setTimeout(() => input?.focus(), 100);

                title.textContent = doc.Ссылка?.match(/(00-\d+)/)?.[1] ?? 'Позиции документа';

                posUl.innerHTML = '';
                const rows = Array.isArray(doc.ТоварыРазмещение) ? doc.ТоварыРазмещение : [];

                const agg = new Map();
                for (const line of rows) {
                    const key = aggKeyFromRow(line);
                    if (!key) continue;
                    if (!agg.has(key)) {
                        agg.set(key, {
                            key,
                            displayNom: String(line.Номенклатура || '-'),
                            displayBC:  String(line.Штрихкод || ''),
                            cell:       String(line.Ячейка || ''),
                            planSum:    Number(line.Количество ?? 0) || 0,
                        });
                    } else {
                        const a = agg.get(key);
                        a.planSum += Number(line.Количество ?? 0) || 0;
                    }
                }

                let localLineCounter = 0;
                for (const a of agg.values()) {
                    const li = document.createElement('li');
                    li.className = 'list-group-item agg-line';

                    li.dataset.aggKey      = a.key;
                    li.dataset.nom         = a.displayNom.toLowerCase();
                    li.dataset.nomOriginal = a.displayNom;
                    li.dataset.barcode     = a.displayBC.toLowerCase();
                    li.dataset.cell        = norm(a.cell);
                    li.dataset.line        = String(++localLineCounter);
                    li.dataset.qty         = String(a.planSum);
                    li.dataset.fact        = '0';

                    renderLi(li);
                    posUl.appendChild(li);
                }

                if (typeof recomputeCountsByCells === 'function') recomputeCountsByCells();
                if (typeof applyTabFilterInPositions === 'function') applyTabFilterInPositions();

                const renderedCount = agg.size;
                if (btnSend) {
                    if (renderedCount > 0) {
                        btnSend.classList.remove('d-none');
                    } else {
                        btnSend.classList.add('d-none');
                    }
                }

                if (btnSend) {
                    if (rows.length > 0) {
                        btnSend.classList.remove('d-none');
                    } else {
                        btnSend.classList.add('d-none');
                    }
                }

                if (!currentWarehouseId) {
                    const wh = inferWarehouseFromFirstRowCell();
                    if (wh) {
                        currentWarehouseId = wh;
                        console.log('[WH] inferred from first row cell →', currentWarehouseId);
                    }
                }

                recomputeCountsByCells();
                applyTabFilterInPositions();

                setWarehouseInStateIfMissing();
                loadCellState();
            }

            // ============== переключение вкладок ==============
            tabs.forEach(tab => {
                tab.addEventListener('click', (e) => {
                    e.preventDefault();
                    tabs.forEach(t => t.classList.remove('active'));
                    tab.classList.add('active');
                    activeTab = tab.dataset.tab || 'gp';

                    const onDocsScreen = !docList.classList.contains('d-none');
                    if (onDocsScreen) {
                        renderDocuments();
                    } else {
                        applyTabFilterInPositions();
                    }
                });
            });

            // ============== кнопка Назад ==============
            if (backBtn) {
                backBtn.addEventListener('click', (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    showDocuments();
                });
            }

            // === Надёжный поиск номера позиции в DOM (без фолбеков на первую строку) ===
            function resolveNumberPosition(rawCode) {
                const code = String(rawCode || '').trim();
                if (!code) return null;

                const isBarcode = /^\d{6,}$/.test(code);
                let found = null;

                if (isBarcode) {
                    const val = code.toLowerCase();
                    document.querySelectorAll('#positionsUl li:not(.d-none)').forEach(li => {
                        if (found !== null) return;
                        const bc = (li.dataset.barcode || '').toLowerCase();
                        if (bc && bc === val) {
                            const n = parseInt(li.dataset.line || '', 10);
                            if (!Number.isNaN(n)) found = n;
                        }
                    });
                }

                if (found === null && !isBarcode) {
                    const val = code.toLowerCase();
                    document.querySelectorAll('#positionsUl li:not(.d-none)').forEach(li => {
                        if (found !== null) return;
                        const nom = (li.dataset.nom || '').toLowerCase();
                        if (nom && nom.includes(val)) {
                            const n = parseInt(li.dataset.line || '', 10);
                            if (!Number.isNaN(n)) found = n;
                        }
                    });
                }

                return found;
            }

            // ============== Сохранение позиции в БД ==============
            async function savePositionScan(rawCode) {
                const code = String(rawCode || '').trim();
                console.log('[SAVE] force external add', { code, currentDocNo, activeState, currentWarehouseId });

                if (!code) {
                    console.warn('[SAVE] empty code - skip');
                    return;
                }
                if (!activeState || !activeState.cell) {
                    console.warn('[SAVE] no active cell in state');
                    alert('Сперва отсканируйте ячейку (экран "Размещение").');
                    return;
                }
                if (!currentDocNo) {
                    console.warn('[SAVE] no currentDocNo');
                    alert('Не удалось определить номер документа.');
                    return;
                }

                const safeForSearch = code.length > CODE_MAX ? code.slice(0, CODE_MAX) : code;

                try {
                    const resp = await fetch(SEARCH_BARCODE_URL, {
                        method: 'POST',
                        headers: {
                            'X-CSRF-TOKEN': csrf,
                            'X-Requested-With': 'XMLHttpRequest',
                            'Accept': 'application/json',
                            'Content-Type': 'application/json',
                        },
                        credentials: 'same-origin',
                        body: JSON.stringify({ barcode: safeForSearch }),
                    });

                    const raw = await resp.text();
                    let data = {};
                    try { data = raw ? JSON.parse(raw) : {}; } catch(e) {}

                    console.log('[SEARCH BARCODE] HTTP', resp.status, data);

                    if (resp.ok && data.ok && Array.isArray(data.items) && data.items.length > 0) {
                        const it = data.items[0];
                        appendExternalItem(it, code);
                        return;
                    }

                    appendExternalItem({ nomen: '(по штрихкоду)', characteristic: null, barcode: code }, code);
                } catch (e) {
                    console.error('[SEARCH BARCODE] fetch error', e);
                    appendExternalItem({ nomen: '(скан)', characteristic: null, barcode: code }, code);
                }
            }

            // ============== поиск/сканер ==============
            let debounceTimer, autoSaveTimer;

            input?.addEventListener('input', () => {
                clearTimeout(debounceTimer);
                debounceTimer = setTimeout(() => {
                    const valRaw = input.value.trim();
                    const val = valRaw.toLowerCase();
                    const isBarcodeQuery = /^\d{6,}$/.test(valRaw);

                    let matchesCount = 0;

                    document.querySelectorAll('#positionsUl li').forEach(li => {
                        if (li.classList.contains('d-none')) {
                            li.classList.remove('hl-barcode');
                            return;
                        }
                        const nom = (li.dataset.nom || '');
                        const bc  = (li.dataset.barcode || '');
                        const match = isBarcodeQuery ? (bc === val) : nom.includes(val);
                        li.classList.toggle('hl-barcode', Boolean(val) && match);
                        if (match) matchesCount++;
                    });

                    if (matchesCount > 0) {
                        const first = document.querySelector('#positionsUl li.hl-barcode:not(.d-none)');
                        if (first) first.scrollIntoView({ block:'center', behavior:'smooth' });
                    }

                    clearTimeout(autoSaveTimer);
                    if (isBarcodeQuery) {
                        autoSaveTimer = setTimeout(() => {
                            console.log('[AUTO] trigger savePositionScan by input');
                            const v = input.value.trim();
                            input.value = '';
                            savePositionScan(v);
                        }, 120);
                    }
                }, 150);
            });

            input?.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' || e.key === 'Tab') {
                    e.preventDefault();
                    const val = input.value.trim();
                    input.value = '';
                    console.log('[KEY]', e.key, '-> savePositionScan');
                    savePositionScan(val);
                }
            });

            // старт: показываем список доков
            showDocuments();

            function getNotScannedRows() {
                const badRows = [];

                document.querySelectorAll('#positionsUl li').forEach(li => {
                    const plan = Number(li.dataset.qty || 0) || 0;
                    const fact = Number(li.dataset.fact || 0) || 0;

                    if (plan > 0 && fact <= 0) {
                        badRows.push({
                            line: li.dataset.line || '-',
                            nom: li.dataset.nomOriginal || '-',
                            plan: plan,
                            fact: fact,
                            element: li,
                        });
                    }
                });

                return badRows;
            }

            // === Кнопка "Отправить" ===
            if (!btnSend) {
                console.warn('[pick] btnSend not found');
            } else {
                console.log('[pick] btnSend wired');
                btnSend.addEventListener('click', async () => {
                    const pageTitleText = document.getElementById('pageTitle')?.textContent || '';
                    const titleNo = (pageTitleText.match(/(00-\d+)/) || [])[1] || '';
                    const number = (window.currentDocumentId && String(window.currentDocumentId)) || titleNo;

                    if (!number) {
                        alert('Не удалось определить номер документа.');
                        return;
                    }

                    const notScannedRows = getNotScannedRows();

                    if (notScannedRows.length > 0) {
                        document.querySelectorAll('#positionsUl li').forEach(li => {
                            li.classList.remove('border-danger');
                        });

                        notScannedRows.forEach(row => {
                            row.element.classList.add('border-danger');
                        });

                        const msg = notScannedRows
                            .map(row => `#${row.line} — ${row.nom} | План: ${row.plan}, Факт: ${row.fact}`)
                            .join('\n');

                        const firstBad = notScannedRows[0]?.element;
                        if (firstBad) {
                            firstBad.scrollIntoView({ block: 'center', behavior: 'smooth' });
                        }

                        const allowSend = await askSendWithoutScanning(
                            'Есть строки, которые ни разу не сканировались:\n\n' +
                            msg +
                            '\n\nЧто делаем?'
                        );

                        if (!allowSend) {
                            input?.focus();
                            return;
                        }
                    }

                    try {
                        btnSend.disabled = true;
                        btnSend.textContent = 'Отправляем...';

                        showSendingModal();

                        const resp = await fetch(FINISH_URL, {
                            method: 'POST',
                            headers: {
                                'X-CSRF-TOKEN': csrf,
                                'X-Requested-With': 'XMLHttpRequest',
                                'Accept': 'application/json',
                                'Content-Type': 'application/json',
                            },
                            body: JSON.stringify({
                                number: number,
                            }),
                        });

                        const raw = await resp.text();
                        let data = {};
                        try { data = raw ? JSON.parse(raw) : {}; } catch (_) {}

                        if (!resp.ok) {
                            sendStatusOverlay?.classList.remove('show');
                            alert((data && (data.msg || JSON.stringify(data))) || ('HTTP ' + resp.status));
                            return;
                        }

                        showSentModal(data?.Документ || 'Операция завершена');

                        setTimeout(() => {
                            window.location.href = '/sklad';
                        }, 1200);
                    } catch (e) {
                        console.error('[finish_acceptance] error', e);
                        sendStatusOverlay?.classList.remove('show');
                        alert('Помилка мережі/сервера');
                    } finally {
                        btnSend.disabled = false;
                        btnSend.textContent = 'Отправить';
                    }
                });
            }
        });

        function askSendWithoutScanning(message) {
            return new Promise(resolve => {
                const old = document.querySelector('.scan-confirm-overlay');
                if (old) old.remove();

                const overlay = document.createElement('div');
                overlay.className = 'scan-confirm-overlay';

                overlay.innerHTML = `
                    <div class="scan-confirm-box">
                        <div class="scan-confirm-title">Есть неотсканированные строки</div>

                        <div class="scan-confirm-text">${message}</div>

                        <div class="scan-confirm-actions">
                            <button type="button" class="btn btn-secondary" data-action="continue">
                                Скан.
                            </button>

                            <button type="button" class="btn btn-danger" data-action="send">
                                Отправить без скана.
                            </button>
                        </div>
                    </div>
                `;

                document.body.appendChild(overlay);

                overlay.querySelector('[data-action="continue"]').addEventListener('click', () => {
                    overlay.remove();
                    resolve(false);
                });

                overlay.querySelector('[data-action="send"]').addEventListener('click', () => {
                    overlay.remove();
                    resolve(true);
                });
            });
        }
    </script>
@endpush

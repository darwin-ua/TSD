<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Database\Eloquent\Model;
use TCG\Voyager\Traits\VoyagerUser; // <-- добавь это


class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable, VoyagerUser;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'id_lk', // Добавляем это поле
        'code_part',
        'name',
        'group',
        'email',
        'password',
        'usertype',
        'role_id',
    ];


    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'password' => 'hashed',
    ];

    public function orders()
    {
        return $this->hasMany(Order::class, 'user_id');
    }

    public function ordersWithStatus($status)
    {
        return $this->hasMany(Order::class, 'user_id')->where('status', $status);
    }


}
